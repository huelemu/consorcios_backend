# 📦 Instalación Completa - Módulo TKS (Tickets)

## Estructura de archivos

```
src/app/features/tickets/
├── components/
│   └── ticket-form/
│       ├── ticket-form.component.html
│       ├── ticket-form.component.ts
│       ├── ticket-form.component.scss
│       └── index.ts
├── models/
│   └── ticket.model.ts
├── services/
│   └── tickets.service.ts
└── pages/
    └── tickets-page/
        ├── tickets-page.component.html
        ├── tickets-page.component.ts
        └── tickets-page.component.scss
```

---

## 1️⃣ Copiar archivos

### Opción A: Reemplazar todo
```bash
# Desde la raíz del proyecto Angular
cp -r COMPLETO/frontend/tickets/* src/app/features/tickets/
```

### Opción B: Manual
1. Reemplazar `/components/ticket-form/` completo
2. Copiar `/models/ticket.model.ts` (si no existe)
3. Copiar `/services/tickets.service.ts` (si no existe)
4. Verificar `/pages/tickets-page/` (ya debe existir)

---

## 2️⃣ Verificar dependencias

### app.config.ts o main.ts
```typescript
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideHttpClient } from '@angular/common/http';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideAnimations(), // ← NECESARIO para MatDialog
    provideHttpClient(), // ← NECESARIO para HTTP
    // ... otros providers
  ]
};
```

### package.json
Verificar que estén instaladas:
```json
{
  "dependencies": {
    "@angular/material": "^18.x.x",
    "@angular/cdk": "^18.x.x",
    "tailwindcss": "^3.x.x"
  }
}
```

Si falta alguna:
```bash
npm install @angular/material @angular/cdk
```

---

## 3️⃣ Integrar en Unidad Detail

### unidad-detail.component.ts

**Agregar imports:**
```typescript
import { MatDialog } from '@angular/material/dialog';
import { TicketFormComponent } from '../../../tickets/components/ticket-form/ticket-form.component';
```

**Agregar en constructor:**
```typescript
constructor(
  private route: ActivatedRoute,
  private router: Router,
  private unidadesService: UnidadesService,
  private authService: AuthService,
  private dialog: MatDialog // ← NUEVO
) {}
```

**Agregar método:**
```typescript
crearTicket(): void {
  const dialogRef = this.dialog.open(TicketFormComponent, {
    width: '900px',
    maxHeight: '90vh',
    disableClose: false,
    data: {
      consorcioId: this.unidad.consorcio_id,
      consorcioNombre: this.unidad.consorcio?.nombre,
      unidadId: this.unidad.id,
      unidadNombre: `${this.unidad.codigo} - Piso ${this.unidad.piso}`
    }
  });

  dialogRef.afterClosed().subscribe((ticket) => {
    if (ticket) {
      console.log('✅ Ticket creado:', ticket);
      // Opcional: Recargar datos
      this.loadUnidad();
    }
  });
}
```

### unidad-detail.component.html

**Agregar botón en sección de acciones (línea ~38):**
```html
<div class="flex gap-3">
  <!-- NUEVO: Botón Crear Ticket -->
  <button
    (click)="crearTicket()"
    class="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 shadow-md hover:shadow-lg flex items-center gap-2">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" />
    </svg>
    Nuevo Ticket
  </button>

  <!-- Botones existentes (Editar, Eliminar) -->
  <button *ngIf="canEdit" (click)="editarUnidad()" class="bg-blue-600...">
    <!-- ... -->
  </button>
</div>
```

---

## 4️⃣ Integrar en Consorcio Detail

### consorcio-detail.component.ts

**Mismos imports que unidad-detail:**
```typescript
import { MatDialog } from '@angular/material/dialog';
import { TicketFormComponent } from '../../../tickets/components/ticket-form/ticket-form.component';
```

**En constructor:**
```typescript
constructor(
  // ... otros servicios
  private dialog: MatDialog // ← NUEVO
) {}
```

**Agregar método:**
```typescript
crearTicket(): void {
  const dialogRef = this.dialog.open(TicketFormComponent, {
    width: '900px',
    maxHeight: '90vh',
    disableClose: false,
    data: {
      consorcioId: this.consorcio.id,
      consorcioNombre: this.consorcio.nombre,
      unidadId: null,
      unidadNombre: null
    }
  });

  dialogRef.afterClosed().subscribe((ticket) => {
    if (ticket) {
      console.log('✅ Ticket creado:', ticket);
      this.loadConsorcio();
    }
  });
}
```

### consorcio-detail.component.html

**Agregar botón similar:**
```html
<button
  (click)="crearTicket()"
  class="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 shadow-md hover:shadow-lg flex items-center gap-2">
  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" />
  </svg>
  Nuevo Ticket
</button>
```

---

## 5️⃣ Actualizar tickets-page (si es necesario)

### tickets-page.component.ts

**Verificar que tenga el método:**
```typescript
openCreateDialog(): void {
  const dialogRef = this.dialog.open(TicketFormComponent, {
    width: '900px',
    maxHeight: '90vh',
    disableClose: false,
    data: {
      consorcioId: null,
      unidadId: null
    }
  });

  dialogRef.afterClosed().subscribe((ticket) => {
    if (ticket) {
      this.loadTickets();
    }
  });
}
```

---

## 6️⃣ Compilar y probar

```bash
# Compilar
ng build
# o en desarrollo
ng serve

# Verificar que no haya errores
```

---

## 7️⃣ Testing

### Escenario 1: Desde Unidad
1. Ir a `/unidades/[id]`
2. Click "Nuevo Ticket"
3. Verificar que consorcio + unidad estén preasignados
4. Completar formulario
5. Guardar

### Escenario 2: Desde Consorcio
1. Ir a `/consorcios/[id]`
2. Click "Nuevo Ticket"
3. Verificar que consorcio esté preasignado
4. Seleccionar unidad (opcional)
5. Guardar

### Escenario 3: Desde Tickets
1. Ir a `/tickets`
2. Click "Nuevo Ticket"
3. Seleccionar consorcio
4. Seleccionar unidad (opcional)
5. Guardar

---

## 🐛 Troubleshooting

### Error: "Can't resolve '@angular/material/dialog'"
```bash
npm install @angular/material @angular/cdk
```

### Error: "No provider for MatDialog"
Verificar que `provideAnimations()` esté en app.config.ts

### Error: "Can't bind to 'formGroup'"
Verificar que `ReactiveFormsModule` esté en imports del componente

### Error: "Can't resolve '../../../tickets/components/ticket-form'"
Verificar la ruta relativa según la ubicación del archivo

### El modal no se ve bien
Verificar que Tailwind esté configurado correctamente en `tailwind.config.js`

### No se cargan consorcios/unidades
Verificar que el backend esté corriendo y los endpoints respondan

---

## ✅ Checklist final

- [ ] Archivos copiados en `/features/tickets/`
- [ ] `provideAnimations()` en app.config.ts
- [ ] Método `crearTicket()` en unidad-detail.component.ts
- [ ] Botón "Nuevo Ticket" en unidad-detail.component.html
- [ ] Método `crearTicket()` en consorcio-detail.component.ts
- [ ] Botón "Nuevo Ticket" en consorcio-detail.component.html
- [ ] Compilación sin errores
- [ ] Prueba desde unidad → funciona
- [ ] Prueba desde consorcio → funciona
- [ ] Prueba desde /tickets → funciona

---

## 📞 Soporte

Si hay errores de compilación, verificar:
1. Versiones de Angular Material compatibles
2. Imports correctos en cada componente
3. Rutas relativas correctas
4. Backend respondiendo correctamente

---

**¡Listo! El módulo TKS debería estar funcionando correctamente.**
