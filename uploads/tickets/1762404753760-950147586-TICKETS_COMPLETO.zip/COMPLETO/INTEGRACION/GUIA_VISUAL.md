# 🎯 GUÍA VISUAL DE INTEGRACIÓN - Tickets

## 📋 Checklist rápido

```
□ Copiar archivos de /COMPLETO/frontend/tickets/
□ Modificar unidad-detail.component.ts
□ Modificar unidad-detail.component.html
□ Modificar consorcio-detail.component.ts
□ Modificar consorcio-detail.component.html
□ Compilar y probar
```

---

## 1️⃣ UNIDAD-DETAIL.COMPONENT.TS

### 📍 Ubicación: `src/app/features/unidades/components/uinidad-detail/unidad-detail.component.ts`

### A. Agregar imports (línea ~1-10)

```typescript
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
// ... otros imports existentes ...
import { MatDialog } from '@angular/material/dialog';  // ← AGREGAR
import { TicketFormComponent } from '../../../tickets/components/ticket-form/ticket-form.component';  // ← AGREGAR
```

### B. Modificar constructor (línea ~50-60)

**ANTES:**
```typescript
constructor(
  private route: ActivatedRoute,
  private router: Router,
  private unidadesService: UnidadesService,
  private authService: AuthService
) {}
```

**DESPUÉS:**
```typescript
constructor(
  private route: ActivatedRoute,
  private router: Router,
  private unidadesService: UnidadesService,
  private authService: AuthService,
  private dialog: MatDialog  // ← AGREGAR ESTA LÍNEA
) {}
```

### C. Agregar método (al final, antes del último `}`)

```typescript
  /**
   * Abre modal para crear ticket
   */
  crearTicket(): void {
    const dialogRef = this.dialog.open(TicketFormComponent, {
      width: '900px',
      maxHeight: '90vh',
      disableClose: false,
      data: {
        consorcioId: this.unidad.consorcio_id,
        consorcioNombre: this.unidad.consorcio?.nombre,
        unidadId: this.unidad.id,
        unidadNombre: `${this.unidad.codigo} - Piso ${this.unidad.piso}`
      }
    });

    dialogRef.afterClosed().subscribe((ticket) => {
      if (ticket) {
        console.log('✅ Ticket creado:', ticket);
        this.loadUnidad();
      }
    });
  }
```

---

## 2️⃣ UNIDAD-DETAIL.COMPONENT.HTML

### 📍 Ubicación: `src/app/features/unidades/components/uinidad-detail/unidad-detail.component.html`

### Buscar esta sección (línea ~38):

```html
      <!-- Actions -->
      <div class="flex gap-3">
```

### Agregar botón DESPUÉS de la apertura del `<div>`:

```html
      <!-- Actions -->
      <div class="flex gap-3">
        
        <!-- NUEVO: Botón Crear Ticket -->
        <button
          (click)="crearTicket()"
          class="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 shadow-md hover:shadow-lg flex items-center gap-2">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" />
          </svg>
          Nuevo Ticket
        </button>

        <!-- EXISTENTE: Botón Editar -->
        <button
          *ngIf="canEdit"
          (click)="editarUnidad()"
          class="bg-blue-600 hover:bg-blue-700...">
          <!-- ... resto del código existente ... -->
```

### 📸 Resultado visual:

```
┌─────────────────────────────────────────────┐
│  ⬅️ Volver                                   │
│                                              │
│  🏠 Unidad A-101  [Ocupada]                 │
│                                              │
│  [🎫 Nuevo Ticket] [✏️ Editar] [🗑️ Eliminar] │
│                                              │
└─────────────────────────────────────────────┘
```

---

## 3️⃣ CONSORCIO-DETAIL.COMPONENT.TS

### 📍 Ubicación: `src/app/features/consorcios/components/consorcio-detail/consorcio-detail.component.ts`

### A. Agregar imports (línea ~1-10)

```typescript
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
// ... otros imports ...
import { MatDialog } from '@angular/material/dialog';  // ← AGREGAR
import { TicketFormComponent } from '../../../tickets/components/ticket-form/ticket-form.component';  // ← AGREGAR
```

### B. Modificar constructor

**ANTES:**
```typescript
constructor(
  private route: ActivatedRoute,
  private router: Router,
  private consorciosService: ConsorciosService,
  private authService: AuthService
) {}
```

**DESPUÉS:**
```typescript
constructor(
  private route: ActivatedRoute,
  private router: Router,
  private consorciosService: ConsorciosService,
  private authService: AuthService,
  private dialog: MatDialog  // ← AGREGAR
) {}
```

### C. Agregar método (al final)

```typescript
  crearTicket(): void {
    const dialogRef = this.dialog.open(TicketFormComponent, {
      width: '900px',
      maxHeight: '90vh',
      disableClose: false,
      data: {
        consorcioId: this.consorcio.id,
        consorcioNombre: this.consorcio.nombre,
        unidadId: null,
        unidadNombre: null
      }
    });

    dialogRef.afterClosed().subscribe((ticket) => {
      if (ticket) {
        console.log('✅ Ticket creado:', ticket);
        this.loadConsorcio();
      }
    });
  }
```

---

## 4️⃣ CONSORCIO-DETAIL.COMPONENT.HTML

### 📍 Ubicación: `src/app/features/consorcios/components/consorcio-detail/consorcio-detail.component.html`

### Buscar sección de botones de acción y agregar:

```html
  <!-- Botón Crear Ticket -->
  <button
    (click)="crearTicket()"
    class="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 shadow-md hover:shadow-lg flex items-center gap-2">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" />
    </svg>
    Nuevo Ticket
  </button>
```

---

## 5️⃣ VERIFICAR APP.CONFIG.TS

### 📍 Ubicación: `src/app/app.config.ts`

### Debe contener:

```typescript
import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideAnimations } from '@angular/platform-browser/animations'; // ← IMPORTANTE
import { provideHttpClient } from '@angular/common/http'; // ← IMPORTANTE

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideAnimations(), // ← NECESARIO para MatDialog
    provideHttpClient(), // ← NECESARIO para HTTP
  ]
};
```

---

## 6️⃣ COMPILAR Y PROBAR

```bash
# Compilar
ng build

# O ejecutar en desarrollo
ng serve
```

### Abrir navegador:

1. **Desde Unidad**: `/unidades/1` → Click "Nuevo Ticket"
   - ✅ Debe preasignar consorcio + unidad
   - ✅ Solo permite editar tipo, prioridad, título, descripción

2. **Desde Consorcio**: `/consorcios/1` → Click "Nuevo Ticket"
   - ✅ Debe preasignar consorcio
   - ✅ Permite seleccionar unidad (dropdown)

3. **Desde Tickets**: `/tickets` → Click "Nuevo Ticket"
   - ✅ Sin preasignaciones
   - ✅ Permite seleccionar consorcio y unidad

---

## 🐛 Troubleshooting

### Error: "Can't resolve MatDialog"
```bash
npm install @angular/material @angular/cdk
```

### Error: "No provider for MatDialog"
Agregar `provideAnimations()` en app.config.ts

### Error: "Property 'codigo' does not exist"
✅ Ya corregido en el HTML (usa `u.nombre || u.unidad`)

### Modal no se abre
Verificar console del navegador para ver errores

### No carga consorcios/unidades
Verificar que backend esté corriendo en `http://localhost:7000`

---

## ✅ Checklist Final

- [ ] Archivos copiados a `/features/tickets/`
- [ ] Imports agregados en unidad-detail.ts
- [ ] Constructor modificado en unidad-detail.ts
- [ ] Método crearTicket() agregado en unidad-detail.ts
- [ ] Botón agregado en unidad-detail.html
- [ ] Imports agregados en consorcio-detail.ts
- [ ] Constructor modificado en consorcio-detail.ts
- [ ] Método crearTicket() agregado en consorcio-detail.ts
- [ ] Botón agregado en consorcio-detail.html
- [ ] app.config.ts tiene provideAnimations()
- [ ] Compilación sin errores
- [ ] Prueba desde unidad → ✅
- [ ] Prueba desde consorcio → ✅
- [ ] Prueba desde /tickets → ✅

---

**¡Listo para usar!** 🚀
