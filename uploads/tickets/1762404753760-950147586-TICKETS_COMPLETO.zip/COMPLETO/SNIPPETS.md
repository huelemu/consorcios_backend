# 📋 Snippets - Copiar y Pegar

## 1. unidad-detail.component.ts

### IMPORTS (agregar al inicio del archivo)
```typescript
import { MatDialog } from '@angular/material/dialog';
import { TicketFormComponent } from '../../../tickets/components/ticket-form/ticket-form.component';
```

### CONSTRUCTOR (modificar para agregar MatDialog)
```typescript
constructor(
  private route: ActivatedRoute,
  private router: Router,
  private unidadesService: UnidadesService,
  private authService: AuthService,
  private dialog: MatDialog // ← AGREGAR ESTA LÍNEA
) {}
```

### MÉTODO (agregar al final de la clase, antes del último })
```typescript
  crearTicket(): void {
    const dialogRef = this.dialog.open(TicketFormComponent, {
      width: '900px',
      maxHeight: '90vh',
      disableClose: false,
      data: {
        consorcioId: this.unidad.consorcio_id,
        consorcioNombre: this.unidad.consorcio?.nombre,
        unidadId: this.unidad.id,
        unidadNombre: `${this.unidad.codigo} - Piso ${this.unidad.piso}`
      }
    });

    dialogRef.afterClosed().subscribe((ticket) => {
      if (ticket) {
        console.log('✅ Ticket creado:', ticket);
        this.loadUnidad();
      }
    });
  }
```

---

## 2. unidad-detail.component.html

### BOTÓN (agregar DENTRO del <div class="flex gap-3"> que contiene los botones Editar/Eliminar)

Buscar esta sección (aproximadamente línea 38):
```html
<!-- Actions -->
<div class="flex gap-3">
```

Y agregar DESPUÉS de la apertura del div pero ANTES del botón "Editar":

```html
  <!-- Botón Crear Ticket -->
  <button
    (click)="crearTicket()"
    class="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 shadow-md hover:shadow-lg flex items-center gap-2">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" />
    </svg>
    Nuevo Ticket
  </button>
```

---

## 3. consorcio-detail.component.ts

### IMPORTS (agregar al inicio)
```typescript
import { MatDialog } from '@angular/material/dialog';
import { TicketFormComponent } from '../../../tickets/components/ticket-form/ticket-form.component';
```

### CONSTRUCTOR (modificar para agregar MatDialog)
```typescript
constructor(
  private route: ActivatedRoute,
  private router: Router,
  private consorciosService: ConsorciosService,
  private authService: AuthService,
  private dialog: MatDialog // ← AGREGAR ESTA LÍNEA
) {}
```

### MÉTODO (agregar al final de la clase)
```typescript
  crearTicket(): void {
    const dialogRef = this.dialog.open(TicketFormComponent, {
      width: '900px',
      maxHeight: '90vh',
      disableClose: false,
      data: {
        consorcioId: this.consorcio.id,
        consorcioNombre: this.consorcio.nombre,
        unidadId: null,
        unidadNombre: null
      }
    });

    dialogRef.afterClosed().subscribe((ticket) => {
      if (ticket) {
        console.log('✅ Ticket creado:', ticket);
        this.loadConsorcio();
      }
    });
  }
```

---

## 4. consorcio-detail.component.html

### BOTÓN (agregar en la sección de acciones)

Buscar el div que contiene los botones de acciones y agregar:

```html
  <!-- Botón Crear Ticket -->
  <button
    (click)="crearTicket()"
    class="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 shadow-md hover:shadow-lg flex items-center gap-2">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" />
    </svg>
    Nuevo Ticket
  </button>
```

---

## 5. tickets-page.component.ts (verificar que exista)

### MÉTODO openCreateDialog (debe estar así):
```typescript
  openCreateDialog(): void {
    const dialogRef = this.dialog.open(TicketFormComponent, {
      width: '900px',
      maxHeight: '90vh',
      disableClose: false,
      data: {
        consorcioId: null,
        unidadId: null
      }
    });

    dialogRef.afterClosed().subscribe((ticket) => {
      if (ticket) {
        this.loadTickets();
      }
    });
  }
```

---

## 6. app.config.ts (o main.ts según tu versión)

### Verificar que tenga estos providers:
```typescript
import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideAnimations } from '@angular/platform-browser/animations'; // ← IMPORTANTE
import { provideHttpClient } from '@angular/common/http'; // ← IMPORTANTE
import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideAnimations(), // ← NECESARIO para MatDialog
    provideHttpClient(), // ← NECESARIO para HTTP requests
  ]
};
```

---

## 7. Comandos para compilar y verificar

```bash
# Instalar dependencias si faltan
npm install @angular/material @angular/cdk

# Compilar
ng build

# O ejecutar en desarrollo
ng serve
```

---

## 📌 Orden de implementación recomendado

1. ✅ Copiar archivos de `/COMPLETO/frontend/tickets/` a `/src/app/features/tickets/`
2. ✅ Verificar app.config.ts tiene `provideAnimations()` y `provideHttpClient()`
3. ✅ Agregar imports, constructor y método en `unidad-detail.component.ts`
4. ✅ Agregar botón en `unidad-detail.component.html`
5. ✅ Agregar imports, constructor y método en `consorcio-detail.component.ts`
6. ✅ Agregar botón en `consorcio-detail.component.html`
7. ✅ Compilar con `ng build` o `ng serve`
8. ✅ Probar en navegador

---

## ⚠️ Notas importantes

- **Rutas relativas**: Verificar que las rutas de import sean correctas según la ubicación de cada archivo
- **MatDialog**: Debe estar disponible globalmente con `provideAnimations()`
- **Nombres de propiedades**: Verificar que `this.unidad.consorcio_id` y `this.consorcio.id` existan en tus modelos
- **Método loadUnidad()**: Si no existe, cambiar por el método que use tu componente para recargar datos

---

**¡Con estos snippets deberías poder integrar todo sin errores!**
